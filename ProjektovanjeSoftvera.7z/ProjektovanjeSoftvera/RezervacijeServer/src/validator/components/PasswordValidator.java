/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validator.components;

import validator.IValidator;
import validator.ValidatorException;

/**
 *
 * @author Bane
 */
public class PasswordValidator implements IValidator {

    public PasswordValidator() {
    }

    @Override
    public void validate(String password) throws ValidatorException {
        if (password.length() < 8) {
            throw new ValidatorException("Password mora imati najmanje 8 karaktera.");
        }

        if (!sadrziSlova(password)) {
            throw new ValidatorException("Password mora sadržati bar jedno slovo.");
        }

        if (!sadrziCifru(password)) {
            throw new ValidatorException("Password mora sadržati bar jednu cifru.");
        }
    }

    private boolean sadrziSlova(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) {
                return true;
            }
        }
        return false;
    }

    private boolean sadrziCifru(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }
}
