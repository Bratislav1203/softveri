/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validator.components;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import validator.IValidator;
import validator.ValidatorException;

/**
 *
 * @author Bratislav
 */
public class TimeValidator implements IValidator {


    @Override
    public void validate(String value) throws ValidatorException {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            Date vreme = sdf.parse(value);
            Date kraj = sdf.parse("00:01");
            Date pocetak = sdf.parse("07:59");
            
            if (vreme.after(kraj) && vreme.before(pocetak)) {
                throw new ValidatorException("Vreme ne sme biti između 00:01 i 07:59.");
            }
        } catch (ParseException ex) {
            System.out.println("Doslo je do greske kod TimeValidatora");
        }
    }

}
