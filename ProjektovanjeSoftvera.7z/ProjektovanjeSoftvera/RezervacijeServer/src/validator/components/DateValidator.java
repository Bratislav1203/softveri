/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package validator.components;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import validator.IValidator;
import validator.ValidatorException;

/**
 *
 * @author Bratislav
 */
public class DateValidator implements IValidator{


    @Override
    public void validate(String value) throws ValidatorException {
        if (value == null || value.isEmpty()) {
            throw new ValidatorException("Polje je obavezno!");
        }
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate datum = LocalDate.parse(value, formatter);
        LocalDate today = LocalDate.now();
        
        if (datum.isBefore(today)) {
            throw new ValidatorException("Datum prikazivanja mora biti u buducnosti!");
        }

    }
}
