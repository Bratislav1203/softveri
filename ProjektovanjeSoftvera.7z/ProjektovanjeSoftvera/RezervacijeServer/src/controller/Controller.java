/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import domen.Bioskop;
import domen.Film;
import domen.Karta;
import domen.Prikaz;
import domen.Rezervacija;
import domen.Sala;
import domen.StavkaRezervacije;
import domen.User;
import operation.AbstractGenericOperation;
import operation.bioskop.CreateBioskop;
import operation.bioskop.DeleteBioskop;
import operation.bioskop.GetAllBioskop;
import operation.bioskop.UpdateBioskop;
import operation.film.CreateFilm;
import operation.film.DeleteFilm;
import operation.film.GetAllFilms;
import operation.film.GetOneFilm;
import operation.film.UpdateFilm;
import operation.karta.CreateKarta;
import operation.karta.DeleteKarta;
import operation.karta.GetAllKarta;
import operation.karta.GetOneKarta;
import operation.karta.UpdateKarta;
import operation.login.LogIn;
import operation.prikaz.AddPrikaz;
import operation.prikaz.CreatePrikaz;
import operation.prikaz.DeletePrikaz;
import operation.prikaz.GetAllPrikaz;
import operation.prikaz.UpdatePrikaz;
import operation.rezervacija.CreateRezervacija;
import operation.rezervacija.DeleteRezervacija;
import operation.rezervacija.GetAllRezervacija;
import operation.rezervacija.UpdateRezervacija;
import operation.sala.AddSala;
import operation.sala.CreateSala;
import operation.sala.DeleteSala;
import operation.sala.GetAllSala;
import operation.sala.UpdateSala;
import operation.stavkarezervacije.AddStavkaRezervacije;
import operation.stavkarezervacije.CreateStavkaRezervacije;
import operation.stavkarezervacije.DeleteStavkaRezervacije;
import operation.stavkarezervacije.GetAllStavkaRezervacije;
import operation.stavkarezervacije.UpdateStavkaRezervacije;
import operation.user.AddUser;
import operation.user.CreateUser;
import operation.user.DeleteUser;
import operation.user.GetAllUsers;
import operation.user.UpdateUser;

/**
 *
 * @author Bratislav
 */
public class Controller {

    private static Controller controller;
    private AbstractGenericOperation operation;

    public Controller() {
    }

    public static Controller getInstance() {
        if (controller == null) {
            controller = new Controller();
        }

        return controller;
    }

    public Object create(Object object) throws Exception {
        if (object instanceof User) {
            return createUser(object);
        }
        if (object instanceof Sala) {
            return createSala(object);
        }
        if (object instanceof StavkaRezervacije) {
            return createStavkaRezervacije(object);
        }
        if (object instanceof Bioskop) {
            return createBioskop(object);
        }
        if (object instanceof Film) {
            return createFilm(object);
        }
        if (object instanceof Karta) {
            return createKarta(object);
        }
        if (object instanceof Rezervacija) {
            return createRezervacija(object);
        }
        if (object instanceof Prikaz) {
            return createPrikaz(object);
        }

        return null;
    }

    public boolean update(Object object) throws Exception {
        if (object instanceof User) {
            return updateUser(object);
        }
        if (object instanceof Sala) {
            return updateSala(object);
        }
        if (object instanceof StavkaRezervacije) {
            return updateStavkaRezervacije(object);
        }
        if (object instanceof Bioskop) {
            return updateBioskop(object);
        }
        if (object instanceof Film) {
            return updateFilm(object);
        }
        if (object instanceof Karta) {
            return updateKarta(object);
        }
        if (object instanceof Rezervacija) {
            return updateRezervacija(object);
        }
        if (object instanceof Prikaz) {
            return updatePrikaz(object);
        }

        return false;
    }

    public boolean add(Object object) throws Exception {
        if (object instanceof User) {
            return addUser(object);
        }
        if (object instanceof Sala) {
            return addSala(object);
        }
        if (object instanceof StavkaRezervacije) {
            return addStavkaRezervacije(object);
        }
        if (object instanceof Prikaz) {
            return addPrikaz(object);
        }

        return false;
    }

    public boolean delete(Object object) throws Exception {
        if (object instanceof User) {
            return deleteUser(object);
        }
        if (object instanceof Sala) {
            return deleteSala(object);
        }
        if (object instanceof StavkaRezervacije) {
            return deleteStavkaRezervacije(object);
        }
        if (object instanceof Bioskop) {
            return deleteBioskop(object);
        }
        if (object instanceof Film) {
            return deleteFilm(object);
        }
        if (object instanceof Karta) {
            return deleteKarta(object);
        }
        if (object instanceof Rezervacija) {
            return deleteRezervacija(object);
        }
        if (object instanceof Prikaz) {
            return deletePrikaz(object);
        }

        return false;
    }

    public Object getAll(Object object) throws Exception {
        if (object instanceof User) {
            return getUseri(object);
        }
        if (object instanceof Sala) {
            return getSale(object);
        }
        if (object instanceof StavkaRezervacije) {
            return getStavkeRezervacije(object);
        }
        if (object instanceof Bioskop) {
            return getBioskopi(object);
        }
        if (object instanceof Film) {
            return getFilmovi(object);
        }
        if (object instanceof Karta) {
            return getKarte(object);
        }
        if (object instanceof Rezervacija) {
            return getRezervacije(object);
        }
        if (object instanceof Prikaz) {
            return getPrikazi(object);
        }

        return null;
    }

    public Object getOne(Object object) throws Exception {
        if (object instanceof Karta) {
            return getOneKarta(object);
        }
        if (object instanceof Film) {
            return getFilm(object);
        }
        return null;
    }

    public Object login(User user) throws Exception {
        operation = new LogIn();
        operation.execute(user);
        return ((LogIn) operation).getLogin();
    }

    public Object createKarta(Object argument) throws Exception {
        operation = new CreateKarta();
        operation.execute(argument);
        return ((CreateKarta) operation).getKarta();
    }

    public Object createBioskop(Object argument) throws Exception {
        operation = new CreateBioskop();
        operation.execute(argument);
        return ((CreateBioskop) operation).getCreatedBioskop();
    }

    public Object createFilm(Object argument) throws Exception {
        operation = new CreateFilm();
        operation.execute(argument);
        return ((CreateFilm) operation).getFilm();
    }

    public Object createUser(Object argument) throws Exception {
        operation = new CreateUser();
        operation.execute(argument);
        return ((CreateUser) operation).getUser();
    }

    public Object createSala(Object argument) throws Exception {
        operation = new CreateSala();
        operation.execute(argument);
        return ((CreateSala) operation).getCreatedSala();
    }

    public Object createStavkaRezervacije(Object argument) throws Exception {
        operation = new CreateStavkaRezervacije();
        operation.execute(argument);
        return ((CreateStavkaRezervacije) operation).getStavkaRezervacije();
    }

    public Object createRezervacija(Object argument) throws Exception {
        operation = new CreateRezervacija();
        operation.execute(argument);
        return ((CreateRezervacija) operation).getCreatedRezervacija();
    }
    
    public Object createPrikaz(Object argument) throws Exception {
        operation = new CreatePrikaz();
        operation.execute(argument);
        return ((CreatePrikaz) operation).getCreatedPrikaz();
    }

    public boolean updateUser(Object argument) throws Exception {
        operation = new UpdateUser();
        operation.execute(argument);
        return ((UpdateUser) operation).confirm();
    }

    public boolean updateSala(Object argument) throws Exception {
        operation = new UpdateSala();
        operation.execute(argument);
        return ((UpdateSala) operation).confirm();
    }

    public boolean updateStavkaRezervacije(Object argument) throws Exception {
        operation = new UpdateStavkaRezervacije();
        operation.execute(argument);
        return ((UpdateStavkaRezervacije) operation).confirm();
    }

    public boolean updateBioskop(Object argument) throws Exception {
        operation = new UpdateBioskop();
        operation.execute(argument);
        return ((UpdateBioskop) operation).confirm();
    }

    public boolean updateFilm(Object argument) throws Exception {
        operation = new UpdateFilm();
        operation.execute(argument);
        return ((UpdateFilm) operation).confirm();
    }

    public boolean updateKarta(Object argument) throws Exception {
        operation = new UpdateKarta();
        operation.execute(argument);
        return ((UpdateKarta) operation).confirm();
    }

    public boolean updateRezervacija(Object argument) throws Exception {
        operation = new UpdateRezervacija();
        operation.execute(argument);
        return ((UpdateRezervacija) operation).confirm();
    }

    public boolean updatePrikaz(Object argument) throws Exception {
        operation = new UpdatePrikaz();
        operation.execute(argument);
        return ((UpdatePrikaz) operation).confirm();
    }

    public boolean addPrikaz(Object argument) throws Exception {
        operation = new AddPrikaz();
        operation.execute(argument);
        return ((AddPrikaz) operation).confirm();
    }

    public boolean deleteUser(Object argument) throws Exception {
        operation = new DeleteUser();
        operation.execute(argument);
        return ((DeleteUser) operation).confirm();
    }

    public boolean deleteSala(Object argument) throws Exception {
        operation = new DeleteSala();
        operation.execute(argument);
        return ((DeleteSala) operation).confirm();
    }

    public boolean deleteStavkaRezervacije(Object argument) throws Exception {
        operation = new DeleteStavkaRezervacije();
        operation.execute(argument);
        return ((DeleteStavkaRezervacije) operation).confirm();
    }

    public boolean deleteBioskop(Object argument) throws Exception {
        operation = new DeleteBioskop();
        operation.execute(argument);
        return ((DeleteBioskop) operation).confirm();
    }

    public boolean deleteFilm(Object argument) throws Exception {
        operation = new DeleteFilm();
        operation.execute(argument);
        return ((DeleteFilm) operation).confirm();
    }

    public boolean deleteKarta(Object argument) throws Exception {
        operation = new DeleteKarta();
        operation.execute(argument);
        return ((DeleteKarta) operation).confirm();
    }

    public boolean deleteRezervacija(Object argument) throws Exception {
        operation = new DeleteRezervacija();
        operation.execute(argument);
        return ((DeleteRezervacija) operation).confirm();
    }

    public boolean deletePrikaz(Object argument) throws Exception {
        operation = new DeletePrikaz();
        operation.execute(argument);
        return ((DeletePrikaz) operation).confirm();
    }

    public Object getUseri(Object argument) throws Exception {
        operation = new GetAllUsers();
        operation.execute(argument);
        return ((GetAllUsers) operation).getUsers();
    }

    public Object getSale(Object argument) throws Exception {
        operation = new GetAllSala();
        operation.execute(argument);
        return ((GetAllSala) operation).getSale();
    }

    public Object getStavkeRezervacije(Object argument) throws Exception {
        operation = new GetAllStavkaRezervacije();
        operation.execute(argument);
        return ((GetAllStavkaRezervacije) operation).getStavke();
    }

    public Object getBioskopi(Object argument) throws Exception {
        operation = new GetAllBioskop();
        operation.execute(argument);
        return ((GetAllBioskop) operation).getBioskopi();
    }

    public Object getFilmovi(Object argument) throws Exception {
        operation = new GetAllFilms();
        operation.execute(argument);
        return ((GetAllFilms) operation).getFilms();
    }

    public Object getKarte(Object argument) throws Exception {
        operation = new GetAllKarta();
        operation.execute(argument);
        return ((GetAllKarta) operation).getKarta();
    }

    public Object getRezervacije(Object argument) throws Exception {
        operation = new GetAllRezervacija();
        operation.execute(argument);
        return ((GetAllRezervacija) operation).getRezervacije();
    }

    public Object getPrikazi(Object argument) throws Exception {
        operation = new GetAllPrikaz();
        operation.execute(argument);
        return ((GetAllPrikaz) operation).getPrikazi();
    }

    public boolean addUser(Object argument) throws Exception {
        operation = new AddUser();
        operation.execute(argument);
        return ((AddUser) operation).confirm();
    }

    public boolean addSala(Object argument) throws Exception {
        operation = new AddSala();
        operation.execute(argument);
        return ((AddSala) operation).confirm();
    }

    public boolean addStavkaRezervacije(Object argument) throws Exception {
        operation = new AddStavkaRezervacije();
        operation.execute(argument);
        return ((AddStavkaRezervacije) operation).confirm();
    }

    private Object getOneKarta(Object argument) throws Exception {
        operation = new GetOneKarta();
        operation.execute(argument);
        return ((GetOneKarta) operation).getKarta();
    }

    private Object getFilm(Object argument) throws Exception {
        operation = new GetOneFilm();
        operation.execute(argument);
        return ((GetOneFilm) operation).getFilm();
    }

}
