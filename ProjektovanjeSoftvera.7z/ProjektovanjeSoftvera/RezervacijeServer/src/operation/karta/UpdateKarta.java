/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.karta;

import domen.Karta;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.NumberValidator;

/**
 *
 * @author Bratislav
 */
public class UpdateKarta extends AbstractGenericOperation{
    
    private boolean flag = false;
    private IValidator validator;
    private String exceptionRed;
    private String exceptionMesto;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws ValidatorException{
        Karta karta = (Karta)param;
        validator = new NumberValidator();
        try {
            validator.validate(String.valueOf(karta.getRed()));
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionRed = ex.getMessage();
            exception = exceptionRed + "," + exception;
        }
        try {
            validator.validate(String.valueOf(karta.getMesto()));
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionMesto = ex.getMessage();
            exception = exceptionMesto + "," + exception;
        }
        if(exceptionRed!=null || exceptionMesto!=null){
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.update((Karta)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
