/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.karta;

import domen.Karta;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetOneKarta extends AbstractGenericOperation{

    private Karta karta;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        karta = (Karta) repository.getOne((Karta)param);
    }
    
    public Karta getKarta(){
        return karta;
    }
}
