/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.karta;

import domen.Karta;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class CreateKarta extends AbstractGenericOperation{

    private Karta karta;
    private String exceptionRed;
    private String exceptionMesto;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws Exception {
        Karta k = (Karta)param;
        if(k.getRed() <= 0){
            exceptionRed= "Red ne sme biti manji ili jednak 0!";
            exception = exceptionRed + "," + exception;
        }
        if(k.getMesto() <= 0 ){
            exceptionMesto = "Mesto ne sme biti manje ili jednako 0!";
            exception = exceptionMesto + "," + exception;
        }
        
        if(exceptionRed!=null || exceptionMesto!=null){
            throw new Exception(exception);
        } 
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        karta = (Karta) repository.create((Karta)param);
    }
    
    public Karta getKarta(){
        return karta;
    }
    
}
