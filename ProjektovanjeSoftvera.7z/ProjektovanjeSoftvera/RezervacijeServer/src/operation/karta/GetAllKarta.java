/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.karta;

import domen.Karta;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllKarta extends AbstractGenericOperation{

    private List<Karta> karte;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        karte = repository.getAll((Karta)param);
    }
    
    public List<Karta> getKarta(){
        return karte;
    }
    
}
