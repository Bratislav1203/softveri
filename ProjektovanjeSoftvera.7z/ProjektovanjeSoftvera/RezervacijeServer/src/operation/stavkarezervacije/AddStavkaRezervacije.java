/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.stavkarezervacije;

import domen.StavkaRezervacije;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;

/**
 *
 * @author Bratislav
 */
public class AddStavkaRezervacije extends AbstractGenericOperation{

    private boolean flag = false;
    
    @Override
    protected void preconditions(Object param) throws ValidatorException {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.add((StavkaRezervacije)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
