/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.stavkarezervacije;

import domen.StavkaRezervacije;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetOneStavkaRezervacije extends AbstractGenericOperation{

    private StavkaRezervacije stavka;
    
    @Override
    protected void preconditions(Object param) throws Exception {
        //Nema ogranicenja
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        stavka = (StavkaRezervacije) repository.getOne((StavkaRezervacije)stavka);
    }
    
    public StavkaRezervacije getStavOdgovor(){
        return stavka;
    }
    
}
