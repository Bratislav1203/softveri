/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.stavkarezervacije;

import domen.StavkaRezervacije;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class DeleteStavkaRezervacije extends AbstractGenericOperation{

    private boolean flag = false;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.delete((StavkaRezervacije)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
