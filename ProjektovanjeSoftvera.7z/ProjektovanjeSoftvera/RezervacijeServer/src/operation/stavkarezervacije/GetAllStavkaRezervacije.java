/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.stavkarezervacije;

import domen.StavkaRezervacije;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllStavkaRezervacije extends AbstractGenericOperation{
    
    private List<StavkaRezervacije> stavke;

    @Override
    protected void preconditions(Object param) throws Exception {
        //Nema ogranicenja
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        stavke = repository.getAll((StavkaRezervacije) param);
    }
    
    public List<StavkaRezervacije> getStavke(){
        return stavke;
    }
    
}
