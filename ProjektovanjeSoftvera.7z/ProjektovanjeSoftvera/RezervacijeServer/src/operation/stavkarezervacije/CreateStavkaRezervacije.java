/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.stavkarezervacije;

import domen.StavkaRezervacije;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class CreateStavkaRezervacije extends AbstractGenericOperation{

    StavkaRezervacije stavkaRezervacije;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }
    
    @Override
    protected void executeOperation(Object param) throws Exception {
        stavkaRezervacije = (StavkaRezervacije) repository.create((StavkaRezervacije)param);
    }
    
    public StavkaRezervacije getStavkaRezervacije(){
        return stavkaRezervacije;
    }
    
}
