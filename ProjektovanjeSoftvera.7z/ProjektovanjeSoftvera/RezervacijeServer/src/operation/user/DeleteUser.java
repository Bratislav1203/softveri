/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.user;

import domen.User;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class DeleteUser extends AbstractGenericOperation{

    private boolean flag = false;
    private String exceptionUsername;
    private String exceptionPassword;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws Exception {
        User u = (User)param;
        if(u.getUsername()==null){
            exceptionUsername = "Username indeksa ne sme biti null!";
            exception = exceptionUsername + "," + exception;
        }
        if(u.getPassword()==null){
            exceptionPassword = "Password ne sme biti null!";
            exception = exceptionPassword + "," + exception;
        }
        
        if(exceptionUsername!=null || exceptionPassword!=null ){
            throw new Exception(exception);
        } 
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.delete((User)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
