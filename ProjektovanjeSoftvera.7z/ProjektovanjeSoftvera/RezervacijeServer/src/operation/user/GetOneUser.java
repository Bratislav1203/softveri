/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.user;

import domen.User;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetOneUser extends AbstractGenericOperation{

    private User user;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        user = (User) repository.getOne((User)param);
    }
    
    public User getUser(){
        return user;
    }
}
