/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.user;

import domen.User;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.OpstiValidator;
import validator.components.PasswordValidator;

/**
 *
 * @author Bratislav
 */
public class UpdateUser extends AbstractGenericOperation{
    
    private boolean flag = false;
    private IValidator validator;
    private String exceptionPassword;
    private String exceptionUsername;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws ValidatorException{
        User user = (User)param;
        validator = new PasswordValidator();
        
        try {
            validator.validate(user.getPassword());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionPassword = ex.getMessage();
            exception = exceptionPassword + "," + exception;
        }
        
        validator = new OpstiValidator();
        try {
            validator.validate(user.getUsername());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionUsername = ex.getMessage();
            exception = exceptionUsername + "," + exception;
        }
        
        if(exceptionPassword!=null || exceptionUsername!=null){
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.update((User)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
