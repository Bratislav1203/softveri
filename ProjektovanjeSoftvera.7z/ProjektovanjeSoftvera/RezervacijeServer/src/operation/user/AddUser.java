/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.user;

import domen.User;
import java.util.logging.Level;
import java.util.logging.Logger;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.OpstiValidator;

/**
 *
 * @author Bratislav
 */
public class AddUser extends AbstractGenericOperation {

    private boolean flag = false;
    private IValidator validator;
    private String exceptionUsername;
    private String exceptionPassword;
    private String exception = "";

    @Override
    protected void preconditions(Object param) throws ValidatorException {
        User user = (User) param;
        
        
        
        if (exceptionUsername != null || exceptionPassword != null ) {
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.add((User) param);
    }

    public boolean confirm() {
        return flag;
    }

}
