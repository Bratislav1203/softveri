/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.user;

import domen.User;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class CreateUser extends AbstractGenericOperation {

    private User user;
    private String exceptionUsername;
    private String exceptionPassword;
    private String exception = "";

    @Override
    protected void preconditions(Object param) throws Exception {
        user = (User) param;

        if (user.getUsername() == null) {
            exceptionUsername = "Username ne sme biti null!";
            exception = exceptionUsername + "," + exception;
        }
        if (user.getPassword()== null) {
            exceptionPassword = "Password ne sme biti null";
            exception = exceptionPassword + "," + exception;
        }

        if (exceptionUsername != null || exceptionPassword != null ) {
            throw new Exception(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        user = (User) repository.create((User) param);
    }

    public User getUser() {
        return user;
    }

}
