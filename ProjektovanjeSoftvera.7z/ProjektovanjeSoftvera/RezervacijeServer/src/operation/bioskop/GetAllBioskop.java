/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.bioskop;

import domen.Bioskop;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllBioskop extends AbstractGenericOperation{
    
    private List<Bioskop> bioskopi;

    @Override
    protected void preconditions(Object param) throws Exception {
        //Nema ogranicenja
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        bioskopi = repository.getAll((Bioskop) param);
    }
    
    public List<Bioskop> getBioskopi(){
        return bioskopi;
    }
    
}
