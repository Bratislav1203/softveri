/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.bioskop;

import domen.Bioskop;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetOneBioskop extends AbstractGenericOperation{

    private Bioskop bioskop;
    
    @Override
    protected void preconditions(Object param) throws Exception {
        //Nema ogranicenja
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        bioskop = (Bioskop) repository.getOne((Bioskop)bioskop);
    }
    
    public Bioskop getBioskop(){
        return bioskop;
    }
    
}
