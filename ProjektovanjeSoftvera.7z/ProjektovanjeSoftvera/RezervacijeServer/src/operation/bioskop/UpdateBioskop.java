/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.bioskop;

import domen.Bioskop;
import java.util.logging.Level;
import java.util.logging.Logger;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.OpstiValidator;

/**
 *
 * @author Bratislav
 */
public class UpdateBioskop extends AbstractGenericOperation {

    private boolean flag = false;
    private IValidator validator;
    private String exceptionNaziv;
    private String exceptionAdresa;
    private String exception = "";

    @Override
    protected void preconditions(Object param) throws ValidatorException {
        Bioskop bioskop = (Bioskop) param;
        validator = new OpstiValidator();
        try {
            validator.validate(bioskop.getNaziv());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionNaziv = ex.getMessage();
            exception = exceptionNaziv + "," + exception;
        }
        try {
            validator.validate(bioskop.getAdresa());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionAdresa = ex.getMessage();
            exception = exceptionAdresa + "," + exception;
        }
        if (exceptionNaziv != null || exceptionAdresa != null ) {
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.update((Bioskop) param);
    }

    public boolean confirm() {
        return flag;
    }

    public String getExceptionText() {
        return exception;
    }

}
