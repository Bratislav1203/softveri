/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.bioskop;

import domen.Bioskop;
import operation.AbstractGenericOperation;
import validator.components.OpstiValidator;

/**
 *
 * @author Bratislav
 */
public class CreateBioskop extends AbstractGenericOperation {

    private Bioskop bioskop;
    private String exceptionNaziv;
    private String exceptionAdresa;
    private String exception = "";

    @Override
    protected void preconditions(Object param) throws Exception {
        Bioskop b = (Bioskop) param;
        if (b.getNaziv() == null) {
            exceptionNaziv = "Naziv ne sme biti null!";
            exception = exceptionNaziv + "," + exception;
        }
        if (b.getAdresa() == null) {
            exceptionAdresa = "Adresa ne sme biti null!";
            exception = exceptionAdresa + "," + exception;
        }

        if (exceptionNaziv != null || exceptionAdresa != null ) {
            throw new Exception(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        bioskop = (Bioskop) repository.create((Bioskop) param);
    }

    public Bioskop getCreatedBioskop() {
        return bioskop;
    }

}
