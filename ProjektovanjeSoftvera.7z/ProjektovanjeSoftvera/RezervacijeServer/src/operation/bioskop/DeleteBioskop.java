/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.bioskop;

import domen.Bioskop;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class DeleteBioskop extends AbstractGenericOperation{

    private boolean flag = false;
    private String exceptionNaziv;
    private String exceptionAdresa;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws Exception {
        if(((Bioskop)param).getNaziv()==null){
            exceptionNaziv = "Naziv ne sme biti null!";
            exception = exceptionNaziv + "," + exception;
        }
        if(((Bioskop)param).getAdresa()== null ){
            exceptionAdresa = "Adresa ne sme biti null";
            exception = exceptionAdresa + "," + exception;
        }
        
        if(exceptionNaziv!=null || exceptionAdresa!=null){
            throw new Exception(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.delete((Bioskop)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
