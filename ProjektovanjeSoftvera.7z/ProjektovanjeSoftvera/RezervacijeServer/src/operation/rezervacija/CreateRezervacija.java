/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.rezervacija;

import domen.Rezervacija;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class CreateRezervacija extends AbstractGenericOperation{

    private Rezervacija rezervacija;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        rezervacija = (Rezervacija) repository.create((Rezervacija)param);
    }
    
    public Rezervacija getCreatedRezervacija(){
        return rezervacija;
    }
    
}
