/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.rezervacija;

import domen.Rezervacija;
import domen.StavkaRezervacije;
import java.util.ArrayList;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllRezervacija extends AbstractGenericOperation{

    private List<Rezervacija> rezervacije;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        rezervacije = repository.getAll((Rezervacija)param);
        List<StavkaRezervacije> stavke = repository.getAll(new StavkaRezervacije());
        for(Rezervacija rezervacija : rezervacije){
            List<StavkaRezervacije> noveStavke = new ArrayList<>();
            for(StavkaRezervacije stavka : stavke){
                if(rezervacija.getKod() == (stavka.getRezervacija().getKod())){
                    noveStavke.add(stavka);
                }
            }
        rezervacija.setStavke(noveStavke);
        }
    }
    
    public List<Rezervacija> getRezervacije(){
        return rezervacije;
    }
    
}
