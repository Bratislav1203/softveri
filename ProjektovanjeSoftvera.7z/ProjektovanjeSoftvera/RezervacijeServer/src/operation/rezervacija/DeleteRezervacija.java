/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.rezervacija;

import domen.Rezervacija;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class DeleteRezervacija extends AbstractGenericOperation{

    private boolean flag = false;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.delete((Rezervacija)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
