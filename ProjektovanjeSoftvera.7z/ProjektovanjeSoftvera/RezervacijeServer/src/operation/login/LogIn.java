/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.login;

import domen.User;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import operation.AbstractGenericOperation;
import operation.user.GetAllUsers;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.OpstiValidator;

/**
 *
 * @author Bratislav
 */
public class LogIn extends AbstractGenericOperation{
    
    private IValidator validator;
    private String exception = "";
    private String exceptionUsername;
    private String exceptionPassword;
    private Object login;

    @Override
    protected void preconditions(Object param) throws ValidatorException{
        User user = (User)param;
        validator = new OpstiValidator();
        try {
            validator.validate(user.getUsername());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionUsername = ex.getMessage();
            exception = exceptionUsername + "," + exception;
        }
        try {
            validator.validate(user.getPassword());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionPassword = ex.getMessage();
            exception = exceptionPassword + "," + exception;
        }
        
        if(exceptionUsername!=null || exceptionPassword!=null){
            System.out.println(exception);
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        User user = (User)param;
        if(user.getUsername().equals("admin") && user.getPassword().equals("admin")){
            login = user;
            return;
        }
        else{
            System.out.println(user.getUsername());
            System.out.println(user.getPassword());
            AbstractGenericOperation ago = new GetAllUsers();
            ago.execute(new User());
            List<User> users = ((GetAllUsers)ago).getUsers();

            for(User u : users){
                String username = u.getUsername();
                String password = u.getPassword();
                


                if(username.equals(user.getUsername()) && password.equals(user.getPassword())){
                    login = u;
                    break;
                }
                else{
                    login = new User();
                }
            }
        }        
    }
    
    public Object getLogin(){
        return login;
    }
    
}
