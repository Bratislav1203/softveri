/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.prikaz;

import domen.Prikaz;
import operation.sala.*;
import domen.Sala;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class CreatePrikaz extends AbstractGenericOperation {

    private Prikaz prikaz;
    private String exception = "";
    private String exceptionDatumPrikazivanja;
    private String exceptionVremePrikazivanja;
    private String exceptionCena;

    @Override
    protected void preconditions(Object param) throws Exception {
        Prikaz p = (Prikaz) param;
        if (p.getDatumPrikazivanja()== null) {
            exceptionDatumPrikazivanja = "Datum prikazivanja ne sme biti null!";
            exception = exceptionDatumPrikazivanja + "," + exception;
        }
        if (p.getVremePrikazivanja()== null) {
            exceptionVremePrikazivanja = "Vreme prikazivanja ne sme biti null!";
            exception = exceptionVremePrikazivanja + "," + exception;
        }
        if (p.getCena() <= 0) {
            exceptionCena = "Cena ne sme biti manja ili jednaka nuli!";
            exception = exceptionCena + "," + exception;
        }

        if (exceptionDatumPrikazivanja != null || exceptionVremePrikazivanja != null  || exceptionCena != null ) {
            throw new Exception(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        prikaz = (Prikaz) repository.create((Prikaz) param);
    }

    public Prikaz getCreatedPrikaz() {
        return prikaz;
    }

}
