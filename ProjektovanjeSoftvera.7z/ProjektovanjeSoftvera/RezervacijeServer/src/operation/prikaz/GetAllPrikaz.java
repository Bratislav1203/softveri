/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.prikaz;

import domen.Prikaz;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllPrikaz extends AbstractGenericOperation{

    private List<Prikaz> prikazi;
    
    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        prikazi = repository.getAll((Prikaz)param);
    }
    
    public List<Prikaz> getPrikazi(){
        return prikazi;
    }
    
}
