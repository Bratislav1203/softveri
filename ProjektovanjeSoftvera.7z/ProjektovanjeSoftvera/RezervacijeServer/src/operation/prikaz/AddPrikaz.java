/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.prikaz;

import domen.Prikaz;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.DateValidator;
import validator.components.NumberValidator;
import validator.components.TimeValidator;

/**
 *
 * @author Bratislav
 */
public class AddPrikaz extends AbstractGenericOperation {

    private boolean flag = false;
    private IValidator validator;
    private String exception = "";
    private String exceptionDatumPrikazivanja;
    private String exceptionVremePrikazivanja;
    private String exceptionCena;

    @Override
    protected void preconditions(Object param) throws ValidatorException {
        Prikaz p = (Prikaz) param;
        IValidator validator = new DateValidator();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            validator.validate(sdf.format(p.getDatumPrikazivanja()));
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionDatumPrikazivanja = ex.getMessage();
            exception = exceptionDatumPrikazivanja + "," + exception;
        }
        validator = new NumberValidator();
        try {
            validator.validate(String.valueOf(p.getCena()));
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionCena = ex.getMessage();
            exception = exceptionCena + "," + exception;
        }
        validator = new TimeValidator();
        sdf = new SimpleDateFormat("HH:mm");
        try {
            validator.validate(sdf.format(p.getVremePrikazivanja()));
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionVremePrikazivanja = ex.getMessage();
            exception = exceptionVremePrikazivanja + "," + exception;
        }
        if (exceptionDatumPrikazivanja != null || exceptionVremePrikazivanja != null || exceptionCena != null) {
            throw new ValidatorException(exception);
        }

    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.add((Prikaz) param);
    }

    public boolean confirm() {
        return flag;
    }

}
