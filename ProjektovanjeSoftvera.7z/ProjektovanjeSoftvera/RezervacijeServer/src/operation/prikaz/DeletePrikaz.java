/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.prikaz;

import domen.Prikaz;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.DateValidator;
import validator.components.TimeValidator;

/**
 *
 * @author Bratislav
 */
public class DeletePrikaz extends AbstractGenericOperation{

    private boolean flag = false;
    private String exceptionDatumPrikazivanja;
    private String exceptionVremePrikazivanja;
    private String exception="";
    private IValidator validator;
    
    @Override
    protected void preconditions(Object param) throws ValidatorException {
        Prikaz p = (Prikaz)param;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        validator = new DateValidator();
        try {
            validator.validate(sdf.format(p.getVremePrikazivanja()));
        } catch (ValidatorException ex) {
            exceptionDatumPrikazivanja = ex.getMessage();
            exception = exceptionDatumPrikazivanja + "," + exception;
        }
        
        validator = new TimeValidator();
        sdf = new SimpleDateFormat("HH:mm");
        try {
            validator.validate(sdf.format(p.getVremePrikazivanja()));
        } catch (ValidatorException ex) {
            exceptionVremePrikazivanja = ex.getMessage();
            exception = exceptionVremePrikazivanja + "," + exception;
        }
        
        if(exceptionDatumPrikazivanja!=null || exceptionVremePrikazivanja!=null){
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.delete((Prikaz)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
