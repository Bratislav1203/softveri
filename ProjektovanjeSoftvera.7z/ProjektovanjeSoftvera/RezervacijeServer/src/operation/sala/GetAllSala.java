/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.sala;

import domen.Sala;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllSala extends AbstractGenericOperation{
    
    private List<Sala> sale;

    @Override
    protected void preconditions(Object param) throws Exception {
        //Nema ogranicenja
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        sale = repository.getAll((Sala) param);
    }
    
    public List<Sala> getSale(){
        return sale;
    }
    
}
