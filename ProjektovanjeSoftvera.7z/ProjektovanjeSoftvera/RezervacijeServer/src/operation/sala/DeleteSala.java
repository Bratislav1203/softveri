/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.sala;

import domen.Sala;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class DeleteSala extends AbstractGenericOperation{

    private boolean flag = false;
    private String exceptionBrojSedista;
    
    @Override
    protected void preconditions(Object param) throws Exception {
        if(((Sala)param).getBrojSedista() <= 0){
            exceptionBrojSedista = "Broj sedista ne sme biti manji ili jednak 0!";
        }
        if(exceptionBrojSedista!=null){
            throw new Exception(exceptionBrojSedista);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.delete((Sala)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
