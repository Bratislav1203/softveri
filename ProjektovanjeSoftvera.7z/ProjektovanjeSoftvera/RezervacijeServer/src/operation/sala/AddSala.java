/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.sala;

import domen.Sala;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.NumberValidator;

/**
 *
 * @author Bratislav
 */
public class AddSala extends AbstractGenericOperation{

    private boolean flag = false;
    private IValidator validator;
    private String exceptionBrojSedista;
    
    @Override
    protected void preconditions(Object param) throws ValidatorException {
        Sala sala = (Sala)param;
        validator = new NumberValidator();
        try {
            validator.validate(String.valueOf(sala.getBrojSedista()));
        } catch (ValidatorException ex) {
            exceptionBrojSedista = ex.getMessage();
        }
        
        if(exceptionBrojSedista!=null){
            throw new ValidatorException(exceptionBrojSedista);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.add((Sala)param);
    }
    
    public boolean confirm(){
        return flag;
    }
    
}
