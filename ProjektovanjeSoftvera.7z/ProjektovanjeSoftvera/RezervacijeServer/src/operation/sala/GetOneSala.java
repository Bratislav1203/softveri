/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.sala;

import domen.Sala;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetOneSala extends AbstractGenericOperation{

    private Sala sala;
    
    @Override
    protected void preconditions(Object param) throws Exception {
        //Nema ogranicenja
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        sala = (Sala) repository.getOne((Sala)sala);
    }
    
    public Sala getSala(){
        return sala;
    }
    
}
