/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.film;

import domen.Bioskop;
import domen.Film;
import domen.Prikaz;
import java.util.ArrayList;
import java.util.List;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class GetAllFilms extends AbstractGenericOperation {

    private List<Film> filmovi;

    @Override
    protected void preconditions(Object param) throws Exception {
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        filmovi = repository.getAll((Film) param);
        List<Prikaz> prikazi = repository.getAll(new Prikaz());
        for (Film film : filmovi) {
            List<Bioskop> bioskopi = new ArrayList<>();
            for (Prikaz p : prikazi) {
                if (film.getFilmID() == p.getFilm().getFilmID()) {
                    bioskopi.add(p.getBioskop());
                }
            }
            film.setBioskopi(bioskopi);
        }
    }

    public List<Film> getFilms() {
        return filmovi;
    }

}
