/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.film;

import domen.Film;
import operation.AbstractGenericOperation;

/**
 *
 * @author Bratislav
 */
public class CreateFilm extends AbstractGenericOperation{

    private Film film;
    private String exceptionNaziv;
    private String exceptionReziser;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws Exception {
        Film f = (Film)param;
        if(f.getNaziv()==null){
            exceptionNaziv = "Naziv ne sme biti null!";
            exception = exceptionNaziv + "," + exception;
        }
        if(f.getReziser()==null){
            exceptionReziser = "Reziser ne sme biti null!";
            exception = exceptionReziser + "," + exception;
        }
        if(exceptionNaziv!=null || exceptionReziser!=null ){
            throw new Exception(exception);
        } 
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        film = (Film) repository.create((Film)param);
    }
    
    public Film getFilm(){
        return film;
    }
    
}
