/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package operation.film;

import domen.Film;
import java.util.logging.Level;
import java.util.logging.Logger;
import operation.AbstractGenericOperation;
import validator.IValidator;
import validator.ValidatorException;
import validator.components.OpstiValidator;
import validator.components.TextValidator;

/**
 *
 * @author Bratislav
 */
public class AddFilm extends AbstractGenericOperation{

    private boolean flag = false;
    private IValidator validator;
    private String exceptionNaziv;
    private String exceptionReziser;
    private String exception="";
    
    @Override
    protected void preconditions(Object param) throws ValidatorException{
        Film film = (Film)param;
        validator = new OpstiValidator();
        try {
            validator.validate(film.getNaziv());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionNaziv = ex.getMessage();
            exception = exceptionNaziv + "," + exception;
        }
        validator = new TextValidator();
        try {
            validator.validate(film.getReziser());
            exception = " " + "," + exception;
        } catch (ValidatorException ex) {
            exceptionReziser = ex.getMessage();
            exception = exceptionReziser + "," + exception;
        }
        
        if(exceptionNaziv!=null || exceptionReziser!=null ){
            throw new ValidatorException(exception);
        }
    }

    @Override
    protected void executeOperation(Object param) throws Exception {
        flag = repository.add((Film)param);
    }
    
    
    public boolean confirm(){
        return flag;
    }
    
    
}
