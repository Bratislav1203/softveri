/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package handler;

import controller.Controller;
import domen.User;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import komunikacija.Response;
import komunikacija.Receiver;
import komunikacija.Sender;
import komunikacija.Request;

/**
 *
 * @author Bratislav
 */
public class ProcessClientRequest extends Thread{

    Socket socket;
    Sender sender;
    Receiver receiver;
    Request zahtev = null;
    Response odgovor = null;
    User activeUser;
    
    public ProcessClientRequest(Socket socket) {
        this.socket = socket;
        sender = new Sender(socket);
        receiver = new Receiver(socket);
    }

    @Override
    public void run() {
        while(true){
            try {
                zahtev = (Request) receiver.receive();
                odgovor = new Response();
                switch(zahtev.getOperation()){
                    case LOGIN:
                        User user = (User) zahtev.getArgument();
                        odgovor.setResult(Controller.getInstance().login(user));
                        activeUser = user;
                        break;
                    case CREATE:
                        odgovor.setResult(Controller.getInstance().create(zahtev.getArgument()));
                        break;
                    case ADD:
                        odgovor.setResult(Controller.getInstance().add(zahtev.getArgument()));
                        break;
                    case UPDATE:
                        odgovor.setResult(Controller.getInstance().update(zahtev.getArgument()));
                        break;
                    case DELETE:
                        odgovor.setResult(Controller.getInstance().delete(zahtev.getArgument()));
                        break;
                    case GET:
                        odgovor.setResult(Controller.getInstance().getAll(zahtev.getArgument()));
                        break;
                    case GET_ONE:
                        odgovor.setResult(Controller.getInstance().getOne(zahtev.getArgument()));
                        break;
                }
                
            } catch (Exception ex) {
                if(odgovor==null){
                    System.out.println("Nema odgovora!");
                }
                else{
                    System.out.println(ex.getMessage());
                    odgovor.setException(ex);
                }
            }
            
           sender.send(odgovor);
        }
    } 
    
    public User getUser() {
        return activeUser;
    }

    public Socket getSocket() {
        return socket;
    }
}
