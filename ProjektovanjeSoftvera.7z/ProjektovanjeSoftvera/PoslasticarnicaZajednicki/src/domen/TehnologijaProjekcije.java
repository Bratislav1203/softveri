/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */
package domen;

/**
 *
 * @author Bratislav1203
 */
public enum TehnologijaProjekcije {
     
    TWO_D("2D"),
    THREE_D("3D"),
    IMAX("IMAX");

    private final String format;

    TehnologijaProjekcije(String format) {
        this.format = format;
    }

    public String getFormat() {
        return format;
    }
}

