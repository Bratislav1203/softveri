/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bratislav1203
 */
public class Bioskop implements GenericEntity {

    private int bioskopID;
    private String naziv;
    private String adresa;
    private List<Sala> sale;
    private List<Film> filmovi;

    public Bioskop(int bioskopID, String naziv, String adresa, List<Sala> sale, List<Film> filmovi) {
        this.bioskopID = bioskopID;
        this.naziv = naziv;
        this.adresa = adresa;
        this.sale = sale;
        this.filmovi = filmovi;
    }

    public Bioskop(int bioskopID, String naziv, String adresa) {
        this.bioskopID = bioskopID;
        this.naziv = naziv;
        this.adresa = adresa;
    }

    public List<Film> getFilmovi() {
        return filmovi;
    }

    public void setFilmovi(List<Film> filmovi) {
        this.filmovi = filmovi;
    }

    public Bioskop() {
        sale = new ArrayList<>();
        filmovi = new ArrayList<>();
    }

    public List<Sala> getSale() {
        return sale;
    }

    public int getBioskopID() {
        return bioskopID;
    }

    public void setBioskopID(int bioskopID) {
        this.bioskopID = bioskopID;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String ispisiTehnologije() {
        String s = "";
        int signal = 0;
        if (sale == null || sale.isEmpty()) {
            return "";
        }
        for (Sala sala : sale) {
            if (signal == 1) {
                s += ", ";
            }
            s += sala.getTehnologijaProjekcije().getFormat();
            signal = 1;
        }

        return s;
    }

    @Override
    public String getTableName() {
        return "bioskop";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "bioskopID,naziv,adresa";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(bioskopID).append(",")
                .append("'").append(naziv).append("',")
                .append("'").append(adresa).append("'");
        System.out.println(sb.toString());
        return sb.toString();
    }

    @Override
    public String getWhereCondition(Object object) {
        return "bioskopID=" + ((Bioskop) object).getBioskopID();
    }

    @Override
    public void setId(Integer id) {
        setBioskopID(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT * FROM bioskop";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        Bioskop bioskop = (Bioskop) object;
        return "naziv=" + "'" + bioskop.getNaziv() + "'" + ", adresa=" + "'" + bioskop.getAdresa() + "'";

    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(bioskopID);
        return sb.toString();
    }

    @Override
    public String getColumnNamesForCreate() {
        return "bioskopID";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        Bioskop b = new Bioskop(rs.getInt("bioskopID"), rs.getString("naziv"), rs.getString("adresa"));
        b.setSale(new ArrayList<>());
        return b;
    }

    public void setSale(List<Sala> sale) {
        this.sale = sale;
    }

}
