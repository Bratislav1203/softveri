/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Bratislav1203
 */
public class Film implements GenericEntity {

    private int filmID;
    private String naziv;
    private String reziser;
    private Zanr[] zanr;
    private List<Bioskop> bioskopi;

    public Film() {
    }

    public Film(int filmID, String naziv, String reziser, Zanr[] zanr, List<Bioskop> bioskopi) {
        this.filmID = filmID;
        this.naziv = naziv;
        this.reziser = reziser;
        this.zanr = zanr;
        this.bioskopi = bioskopi;

    }

    public Film(int filmID, String naziv, String reziser) {
        this.filmID = filmID;
        this.naziv = naziv;
        this.reziser = reziser;
    }

    public String getReziser() {
        return reziser;
    }

    public void setReziser(String reziser) {
        this.reziser = reziser;
    }

    public int getFilmID() {
        return filmID;
    }

    public void setFilmID(int filmID) {
        this.filmID = filmID;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Zanr[] getZanr() {
        return zanr;
    }

    public void setZanr(Zanr[] zanr) {
        this.zanr = zanr;
    }

    public String ispisiZanrove() {
        String s = "";
        
        if (zanr == null) {
            return s;
        }
        
        int signal = 0;
        for (int i = 0; i < zanr.length; i++) {
            if (signal == 1) {
                s += ", ";
            }
            s += zanr[i];
            signal = 1;
        }

        return s;
    }

    public void postaviZanr(String zanr) {
        if (zanr.isEmpty()) {
            setZanr(null);
            return;
        }
        String[] zanroviString = zanr.split(",");
        Zanr[] zanrovi = new Zanr[zanroviString.length];

        for (int i = 0; i < zanroviString.length; i++) {
            zanroviString[i] = zanroviString[i].trim();
            zanrovi[i] = Zanr.valueOf(zanroviString[i].toUpperCase());
        }
        setZanr(zanrovi);

    }

    public List<Bioskop> getBioskopi() {
        return bioskopi;
    }

    public void setBioskopi(List<Bioskop> bioskopi) {
        this.bioskopi = bioskopi;
    }

    @Override
    public String getTableName() {
        return "film";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "filmID,naziv,reziser,zanr";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(filmID).append(",")
                .append("'").append(naziv).append("',")
                .append("'").append(reziser).append("',")
                .append("'").append(ispisiZanrove()).append("'");
        return sb.toString();
    }

    @Override
    public String getWhereCondition(Object object) {
        return "filmID=" + ((Film) object).getFilmID();
    }

    @Override
    public void setId(Integer id) {
        setFilmID(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT * FROM film";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        Film film = (Film) object;
        return "naziv=" + "'" + film.getNaziv() + "'" + ", reziser=" + "'" + film.getReziser() + "'" + ", zanr=" + "'" + film.ispisiZanrove() + "'";

    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(filmID);
        return sb.toString();
    }

    @Override
    public String getColumnNamesForCreate() {
        return "filmID";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        Film f = new Film();
        f.setFilmID(rs.getInt("filmID"));
        f.setNaziv(rs.getString("naziv"));
        f.setReziser(rs.getString("reziser"));
        String zanrovi = rs.getString("zanr");

        String[] delovi = zanrovi.split(",");
        int brojac = 0;
        Zanr[] zanr = new Zanr[delovi.length];
        // Iteriramo kroz niz delova i ispisujemo ih
        for (String deo : delovi) {
            for (Zanr z : Zanr.values()){
                deo = deo.toUpperCase().trim();
                if(deo.equals(z.toString().toUpperCase())){
                    zanr[brojac] = z;
                    brojac++;
                }
            }
        }
        f.setZanr(zanr);

        return f;
    }
}
