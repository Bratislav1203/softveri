/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

/**
 *
 * @author Bratislav
 */
public class StavkaRezervacije implements GenericEntity {

    private int stavkaRezervacijeID;
    private Rezervacija rezervacija;
    private Karta karta;

    public StavkaRezervacije(int stavkaRezevacijeID, Rezervacija rezervacija, Karta karta) {
        this.stavkaRezervacijeID = stavkaRezevacijeID;
        this.rezervacija = rezervacija;
        this.karta = karta;
    }

    public StavkaRezervacije() {
    }

    public int getStavkaRezervacijeID() {
        return stavkaRezervacijeID;
    }

    public void setStavkaRezervacijeID(int stavkaRezervacijeID) {
        this.stavkaRezervacijeID = stavkaRezervacijeID;
    }

    public Rezervacija getRezervacija() {
        return rezervacija;
    }

    public void setRezervacija(Rezervacija rezervacija) {
        this.rezervacija = rezervacija;
    }

    public Karta getKarta() {
        return karta;
    }

    public void setKarta(Karta karta) {
        this.karta = karta;
    }

    @Override
    public String getTableName() {
        return "stavkaRezervacije";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "stavkaRezervacijeID,rezervacija,karta";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(stavkaRezervacijeID).append(",")
                .append("'").append(rezervacija.getKod()).append("',")
                .append("'").append(karta.getKartaID()).append("'");
        return sb.toString();

    }

    @Override
    public String getWhereCondition(Object object) {
        return "stavkarezervacijeID=" + ((StavkaRezervacije) object).getStavkaRezervacijeID() + " AND rezervacija=" + ((StavkaRezervacije) object).getRezervacija().getKod();
    }

    @Override
    public void setId(Integer id) {
        setStavkaRezervacijeID(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT s.Stavkarezervacijeid, s.rezervacija,s.karta,k.red, k.mesto,k.prikaz, p.film, p.bioskop, p.datumprikazivanja, p.vremeprikazivanja, p.cena,p.sala, b.naziv AS nazivbioskopa, b.adresa, f.naziv AS nazivfilma, f.reziser, f.zanr, sa.brojredova, sa.brojmesta, sa.tehnologijaprojekcije, p.zauzetamesta FROM stavkarezervacije s JOIN karta k ON s.karta = k.kartaid JOIN prikaz p ON k.prikaz = p.prikazid JOIN bioskop b ON p.bioskop=b.bioskopid JOIN film f ON p.film = f.filmid JOIN sala sa ON p.sala=sa.brojsale GROUP BY stavkarezervacijeid";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        StavkaRezervacije stavkaRezervacije = (StavkaRezervacije) object;
        return "karta=" + "'" + stavkaRezervacije.getKarta().getKartaID() + "'";
    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(getStavkaRezervacijeID()).append(",")
                .append(getRezervacija().getKod());
        return sb.toString();
    }

    @Override
    public String getColumnNamesForCreate() {
        return "stavkarezervacijeID,rezervacija";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        StavkaRezervacije sr = new StavkaRezervacije();
        sr.setStavkaRezervacijeID(rs.getInt("stavkarezervacijeID"));
        Rezervacija rezervacija = new Rezervacija();
        rezervacija.setKod(rs.getInt("rezervacija"));
        sr.setRezervacija(rezervacija);
        Karta karta = new Karta();
        karta.setKartaID(rs.getInt("karta"));
        karta.setMesto(rs.getInt("mesto"));
        karta.setRed(rs.getInt("red"));
        Bioskop bioskop = new Bioskop();
        bioskop.setBioskopID(rs.getInt("bioskop"));
        bioskop.setAdresa(rs.getString("adresa"));
        bioskop.setNaziv(rs.getString("nazivbioskopa"));
        Film film = new Film();
        film.setNaziv(rs.getString("nazivfilma"));
        film.setReziser(rs.getString("reziser"));
        film.setFilmID(rs.getInt("film"));
        film.postaviZanr(rs.getString("zanr").toUpperCase());
        Sala sala = new Sala();
        sala.setBioskop(bioskop);
        sala.setBrojSale(rs.getInt("sala"));
        int a = rs.getInt("brojredova"), b = rs.getInt("brojmesta");
        int[] dimenzije = {a, b};
        String tehnologija = (rs.getString("tehnologijaprojekcije"));
        TehnologijaProjekcije tehp = null;
        for (TehnologijaProjekcije tp : TehnologijaProjekcije.values()) {
            if (tp.getFormat().equalsIgnoreCase(tehnologija)) {
                tehp = tp;
                break;
            }
        }
        sala.setTehnologijaProjekcije(tehp);
        sala.setDimenzijeSale(dimenzije);
        sala.setBrojSedista(a * b);
        Prikaz prikaz = new Prikaz();
        prikaz.postaviZauzetaMesta(rs.getString("zauzetamesta"));
        prikaz.setPrikazID(rs.getInt("prikaz"));
        prikaz.setBioskop(bioskop);
        prikaz.setFilm(film);
        java.sql.Date sqlDate = rs.getDate("datumprikazivanja");
        Date javaDate = new Date(sqlDate.getTime());
        System.out.println(javaDate);
        prikaz.setDatumPrikazivanja(javaDate);
        java.sql.Timestamp sqlTimestamp = rs.getTimestamp("vremeprikazivanja");
        javaDate = new Date(sqlTimestamp.getTime());
        System.out.println(javaDate);
        prikaz.setVremePrikazivanja(javaDate);
        prikaz.setCena(rs.getInt("cena"));
        prikaz.setSala(sala);
        karta.setPrikaz(prikaz);
        sr.setKarta(karta);

        return sr;
    }
}
