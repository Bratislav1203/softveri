/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Bratislav
 */
public class Prikaz implements GenericEntity {

    private int prikazID;
    private Date datumPrikazivanja;
    private Date vremePrikazivanja;
    private Film film;
    private Bioskop bioskop;
    private Sala sala;
    private double cena;
    private int[] zauzetaMesta;

    public Prikaz() {
    }

    public Prikaz(int prikazID, Date datumPrikazivanja, Date vremePrikazivanja, Film film, Bioskop bioskop, Sala sala, double cena, int[] zauzetaMesta) {
        this.prikazID = prikazID;
        this.datumPrikazivanja = datumPrikazivanja;
        this.vremePrikazivanja = vremePrikazivanja;
        this.film = film;
        this.bioskop = bioskop;
        this.sala = sala;
        this.cena = cena;
        this.zauzetaMesta = zauzetaMesta;
    }

    public Prikaz(int prikazID, Date datumPrikazivanja, Film film, Bioskop bioskop, Date pocetakFilma, Sala sala, double cena) {
        this.datumPrikazivanja = datumPrikazivanja;
        this.film = film;
        this.bioskop = bioskop;
        this.prikazID = prikazID;
        this.vremePrikazivanja = pocetakFilma;
        this.sala = sala;
        this.cena = cena;
    }

    public Date getVremePrikazivanja() {
        return vremePrikazivanja;
    }

    public void setVremePrikazivanja(Date vremePrikazivanja) {
        this.vremePrikazivanja = vremePrikazivanja;
    }

    public Bioskop getBioskop() {
        return bioskop;
    }

    public void setBioskop(Bioskop bioskop) {
        this.bioskop = bioskop;
    }

    public Date getDatumPrikazivanja() {
        return datumPrikazivanja;
    }

    public void setDatumPrikazivanja(Date datumPrikazivanja) {
        this.datumPrikazivanja = datumPrikazivanja;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    public int getPrikazID() {
        return prikazID;
    }

    public void setPrikazID(int prikazID) {
        this.prikazID = prikazID;
    }

    public Sala getSala() {
        return sala;
    }

    public void setSala(Sala sala) {
        this.sala = sala;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public void postaviZauzetaMesta(String zauzetaMesta) {
        if (zauzetaMesta.isEmpty()) {
            setZauzetaMesta(null);
            return;
        }
        String[] mestaString = zauzetaMesta.split(",");
        int[] rezultat = new int[mestaString.length];

        for (int i = 0; i < mestaString.length; i++) {
            rezultat[i] = Integer.parseInt(mestaString[i]);
        }
        setZauzetaMesta(rezultat);
    }

    @Override
    public String getTableName() {
        return "prikaz";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "prikazID,film,bioskop,datumPrikazivanja,vremePrikazivanja,cena,sala,zauzetamesta";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(prikazID).append(",")
                .append("'").append(film.getFilmID()).append("',")
                .append("'").append(bioskop.getBioskopID()).append("',")
                .append("'").append(new java.sql.Date(datumPrikazivanja.getTime())).append("',")
                .append("'").append(new Timestamp(vremePrikazivanja.getTime())).append("',")
                .append("'").append(cena).append("',")
                .append("'").append(sala.getBrojSale()).append("',")
                .append("'").append(ispisiZauzetaMesta()).append("'");
        return sb.toString();
    }

    @Override
    public String getWhereCondition(Object object) {
        return "prikazID=" + ((Prikaz) object).getPrikazID();
    }

    @Override
    public void setId(Integer id) {
        setPrikazID(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT p.prikazid, p.film, p.bioskop, p.datumprikazivanja, p.vremeprikazivanja, p.cena, p.sala, b.naziv AS nazivbioskopa, b.adresa, f.naziv AS nazivfilma, f.reziser, f.zanr, sa.brojredova, sa.brojmesta, sa.tehnologijaprojekcije, p.zauzetamesta FROM prikaz p JOIN bioskop b ON p.bioskop=b.bioskopid JOIN film f ON p.film = f.filmid JOIN sala sa ON p.sala=sa.brojsale GROUP BY p.prikazid";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        Prikaz prikaz = (Prikaz) object;
        return "film=" + "'" + prikaz.getFilm().getFilmID() + "'" + ", bioskop=" + "'" + prikaz.getBioskop().getBioskopID() + "'" + ", datumPrikazivanja=" + "'" + new java.sql.Date(prikaz.getDatumPrikazivanja().getTime()) + "', vremePrikazivanja=" + "'" + new Timestamp(prikaz.getVremePrikazivanja().getTime()) + "'" + ", cena=" + "'" + prikaz.getCena() + "'" + ", sala=" + "'" + prikaz.getSala().getBrojSale() + "'" + ",zauzetamesta='" + ispisiZauzetaMesta() + "'";

    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(prikazID);
        return sb.toString();

    }

    @Override
    public String getColumnNamesForCreate() {
        return "prikazID";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        Prikaz p = new Prikaz();
        Film f = new Film();
        Bioskop b = new Bioskop();
        Sala s = new Sala();

        p.setPrikazID(rs.getInt("prikazID"));
        f.setFilmID(rs.getInt("film"));
        f.setNaziv(rs.getString("nazivfilma"));
        f.setReziser(rs.getString("reziser"));
        f.postaviZanr(rs.getString("zanr"));
        b.setBioskopID(rs.getInt("bioskop"));
        b.setNaziv(rs.getString("nazivbioskopa"));
        b.setAdresa(rs.getString("adresa"));
        b.setSale(new ArrayList<>());
        s.setBrojSale(rs.getInt("sala"));
        s.setBioskop(bioskop);
        String tehnologija = (rs.getString("tehnologijaprojekcije"));
        TehnologijaProjekcije tehp = null;
        for (TehnologijaProjekcije tp : TehnologijaProjekcije.values()) {
            if (tp.getFormat().equalsIgnoreCase(tehnologija)) {
                tehp = tp;
                break;
            }
        }
        s.setTehnologijaProjekcije(tehp);
        int[] dimenzije = new int[2];
        dimenzije[0] = (rs.getInt("brojRedova"));
        dimenzije[1] = (rs.getInt("brojMesta"));
        s.setDimenzijeSale(dimenzije);
        s.setBrojSedista(dimenzije[0] * dimenzije[1]);

        p.setDatumPrikazivanja(rs.getDate("datumPrikazivanja"));
        p.setVremePrikazivanja(rs.getTimestamp("vremePrikazivanja"));
        p.setCena(rs.getInt("cena"));
        p.setBioskop(b);
        p.setFilm(f);
        p.setSala(s);
        p.postaviZauzetaMesta(rs.getString("zauzetamesta"));

        return p;

    }

    public int[] getZauzetaMesta() {
        return zauzetaMesta;
    }

    public void setZauzetaMesta(int[] zauzetaMesta) {
        this.zauzetaMesta = zauzetaMesta;
    }

    private String ispisiZauzetaMesta() {
        String zauzetaMesta = "";
        if (this.zauzetaMesta == null || this.zauzetaMesta.length == 0) {
            return zauzetaMesta;
        }
        for (int i = 0; i < this.zauzetaMesta.length; i++) {
            zauzetaMesta += this.zauzetaMesta[i];
            if (i != this.zauzetaMesta.length - 1) {
                zauzetaMesta += ",";
            }
        }
        return zauzetaMesta;
    }

    public void izbaciZauzetoMesto(int zauzetoMesto) {
        int[] noviNiz = new int[zauzetaMesta.length - 1];
        int i = 0;
        for (int broj : zauzetaMesta) {
            if (broj != zauzetoMesto) {
                noviNiz[i] = broj;
                i++;
            }
        }
        setZauzetaMesta(noviNiz);
    }
}
