/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domen;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bratislav
 */
public class Sala implements GenericEntity {

    private int brojSale;
    private Bioskop bioskop;
    private int[] dimenzijeSale;
    private int brojSedista;
    private TehnologijaProjekcije tehnologijaProjekcije;

    public Sala(int brojSale, Bioskop bioskop, TehnologijaProjekcije tehnologijaProjekcije, int[] dimenzijeSale) {
        this.brojSale = brojSale;
        this.bioskop = bioskop;
        this.dimenzijeSale = dimenzijeSale;
        this.brojSedista = dimenzijeSale[0] * dimenzijeSale[1];
        this.tehnologijaProjekcije = tehnologijaProjekcije;
    }

    public Sala() {
    }

    public int getBrojSedista() {
        return brojSedista;
    }

    public void setBrojSedista(int brojSedista) {
        this.brojSedista = brojSedista;
    }

    public int getBrojSale() {
        return brojSale;
    }

    public void setBrojSale(int brojSale) {
        this.brojSale = brojSale;
    }

    public Bioskop getBioskop() {
        return bioskop;
    }

    public void setBioskop(Bioskop bioskop) {
        this.bioskop = bioskop;
    }

    public int[] getDimenzijeSale() {
        return dimenzijeSale;
    }

    public void setDimenzijeSale(int[] dimenzijeSale) {
        this.dimenzijeSale = dimenzijeSale;
    }

    public TehnologijaProjekcije getTehnologijaProjekcije() {
        return tehnologijaProjekcije;
    }

    public void setTehnologijaProjekcije(TehnologijaProjekcije tehnologijaProjekcije) {
        this.tehnologijaProjekcije = tehnologijaProjekcije;
    }

    @Override
    public String getTableName() {
        return "sala";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "brojsale,bioskop,brojredova,brojmesta,tehnologijaprojekcije";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(brojSale).append(",")
                .append("'").append(bioskop.getBioskopID()).append("',")
                .append("'").append(dimenzijeSale[0]).append("',")
                .append("'").append(dimenzijeSale[1]).append("',")
                .append("'").append(tehnologijaProjekcije.getFormat()).append("'");
        return sb.toString();
    }

    @Override
    public String getWhereCondition(Object object) {
        return "brojsale=" + ((Sala) object).getBrojSale() + " AND bioskop=" + ((Sala) object).getBioskop().getBioskopID();
    }

    @Override
    public void setId(Integer id) {
        setBrojSale(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT s.brojsale, s.bioskop, s.brojredova, s.brojmesta, s.tehnologijaprojekcije, b.naziv, b.adresa FROM sala s JOIN bioskop b ON s.bioskop = b.bioskopid";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        Sala sala = (Sala) object;
        return "brojRedova=" + "'" + sala.getDimenzijeSale()[0] + "'" + ", brojMesta=" + "'" + sala.getDimenzijeSale()[1] + "'" + ", tehnologijaProjekcije=" + "'" + sala.getTehnologijaProjekcije() + "'";
    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.valueOf(brojSale)).append(",")
                .append(bioskop.getBioskopID());
        return sb.toString();
    }

    @Override
    public String getColumnNamesForCreate() {
        return "brojSale,bioskop";

    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        Sala s = new Sala();
        Bioskop b = new Bioskop();
        b.setAdresa(rs.getString("adresa"));
        b.setNaziv(rs.getString("naziv"));
        b.setSale(new ArrayList<>());
        b.setBioskopID(rs.getInt("bioskop"));
        s.setBrojSale(rs.getInt("brojSale"));
        b.setBioskopID(rs.getInt("bioskop"));
        s.setBioskop(b);
        int[] dimenzije = new int[2];
        dimenzije[0] = (rs.getInt("brojRedova"));
        dimenzije[1] = (rs.getInt("brojMesta"));
        s.setDimenzijeSale(dimenzije);
        s.setBrojSedista(dimenzije[0]*dimenzije[1]);
        
        String tehnologija = (rs.getString("tehnologijaprojekcije"));
        TehnologijaProjekcije tehp = null;
        for (TehnologijaProjekcije tp : TehnologijaProjekcije.values()) {
            if (tp.getFormat().equalsIgnoreCase(tehnologija)) {
                tehp = tp;
                break;
            }
        }
        s.setTehnologijaProjekcije(tehp);

        return s;
    }
}
