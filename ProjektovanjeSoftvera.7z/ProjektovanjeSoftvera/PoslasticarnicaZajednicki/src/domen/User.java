/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Bratislav1203
 */
public class User implements GenericEntity {

    private int userID;
    private String username;
    private String password;
    private List<Rezervacija> rezervacije;

    public User() {
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(int userID, String username, List<Rezervacija> rezervacije, String password) {
        this.userID = userID;
        this.username = username;
        this.password = password;
        this.rezervacije = rezervacije;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<Rezervacija> getRezervacije() {
        return rezervacije;
    }

    public void setRezervacije(List<Rezervacija> rezervacije) {
        this.rezervacije = rezervacije;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getTableName() {
        return "user";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "userID,username,password";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(userID).append(",")
                .append("'").append(username).append("',")
                .append("'").append(password).append("'");
        return sb.toString();
    }

    @Override
    public String getWhereCondition(Object object) {
        return "userID=" + ((User) object).getUserID();
    }

    @Override
    public void setId(Integer id) {
        setUserID(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT * FROM user";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        User user = (User) object;
        return "username=" + "'" + user.getUsername() + "'" + ", password=" + "'" + user.getPassword() + "'";

    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(userID);
        return sb.toString();

    }

    @Override
    public String getColumnNamesForCreate() {
        return "userID";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserID(rs.getInt("userID"));
        u.setUsername(rs.getString("username"));
        u.setPassword(rs.getString("password"));

        return u;

    }

}
