/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author Bratislav1203
 */
public class Rezervacija implements GenericEntity {

    private int kod;
    private User user;
    private List<StavkaRezervacije> stavke;

    public Rezervacija() {
    }

    public Rezervacija(int kod, User user, List<StavkaRezervacije> stavke) {
        this.kod = kod;
        this.user = user;
        this.stavke = stavke;
    }

    public List<StavkaRezervacije> getStavke() {
        return stavke;
    }

    public void setStavke(List<StavkaRezervacije> stavke) {
        this.stavke = stavke;
    }

    public int getKod() {
        return kod;
    }

    public void setKod(int kod) {
        this.kod = kod;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    @Override
    public String getTableName() {
        return "rezervacija";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "kod,user";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(kod).append(",")
                .append("'").append(user.getUserID()).append("'");
        return sb.toString();

    }

    @Override
    public String getWhereCondition(Object object) {
        return "kod=" + ((Rezervacija) object).getKod();
    }

    @Override
    public void setId(Integer id) {
        setKod(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT * FROM rezervacija";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        Rezervacija rezervacija = (Rezervacija) object;
        return "kod=" + "'" + rezervacija.getKod() + "'" + ", user=" + "'" + rezervacija.getUser().getUsername() + "'";
    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(kod);
        return sb.toString();

    }

    @Override
    public String getColumnNamesForCreate() {
        return "kod";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        Rezervacija r = new Rezervacija();
        User k = new User();
        r.setKod(rs.getInt("kod"));
        k.setId(rs.getInt("user"));
        r.setUser(k);

        return r;
    }

}
