/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package domen;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author Bratislav
 */
public class Karta implements GenericEntity {

    private int kartaID;
    private int red;
    private int mesto;
    private Prikaz prikaz;

    public Karta() {
    }

    public Karta(int kartaID, int red, int mesto, Prikaz prikaz) {
        this.kartaID = kartaID;
        this.red = red;
        this.mesto = mesto;
        this.prikaz = prikaz;
    }

    public Prikaz getPrikaz() {
        return prikaz;
    }

    public void setPrikaz(Prikaz prikaz) {
        this.prikaz = prikaz;
    }

    public int getKartaID() {
        return kartaID;
    }

    public void setKartaID(int kartaID) {
        this.kartaID = kartaID;
    }

    public int getRed() {
        return red;
    }

    public void setRed(int red) {
        this.red = red;
    }

    public int getMesto() {
        return mesto;
    }

    public void setMesto(int mesto) {
        this.mesto = mesto;
    }

    @Override
    public String getTableName() {
        return "karta";
    }

    @Override
    public String getColumnNamesForInsert() {
        return "kartaID,red,mesto,prikaz";
    }

    @Override
    public String getInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(kartaID).append(",")
                .append("'").append(red).append("',")
                .append("'").append(mesto).append("',")
                .append("'").append(prikaz.getPrikazID()).append("'");
        return sb.toString();
    }

    @Override
    public String getWhereCondition(Object object) {
        return "kartaID=" + ((Karta) object).getKartaID();
    }

    @Override
    public void setId(Integer id) {
        setKartaID(id);
    }

    @Override
    public String getSelectValues() {
        return "SELECT k.kartaid, k.red, k.mesto,k.prikaz, p.film, p.bioskop, p.datumprikazivanja, p.vremeprikazivanja, p.cena,p.sala, b.naziv as nazivbioskopa, b.adresa, f.naziv as nazivfilma, f.reziser, f.zanr, sa.brojredova, sa.brojmesta, sa.tehnologijaprojekcije, p.zauzetamesta FROM karta k JOIN prikaz p ON k.prikaz = p.prikazid JOIN bioskop b ON p.bioskop=b.bioskopid JOIN film f ON p.film = f.filmid JOIN sala sa ON p.sala=sa.brojsale";
    }

    @Override
    public String getDeleteAndUpdateCondition(Object object) {
        return getWhereCondition(object);
    }

    @Override
    public String getUpdateSetValues(Object object) {
        Karta karta = (Karta) object;
        return "Red= " + "'" + karta.getRed() + "'" + ", mesto=" + "'" + karta.getMesto() + "'";
    }

    @Override
    public String getCreateInsertValues() {
        StringBuilder sb = new StringBuilder();
        sb.append(kartaID);
        return sb.toString();
    }

    @Override
    public String getColumnNamesForCreate() {
        return "kartaID";
    }

    @Override
    public GenericEntity getNewObject(ResultSet rs) throws SQLException {
        Karta karta = new Karta();
        karta.setKartaID(rs.getInt("kartaid"));
        karta.setMesto(rs.getInt("mesto"));
        karta.setRed(rs.getInt("red"));
        Bioskop bioskop = new Bioskop();
        bioskop.setBioskopID(rs.getInt("bioskop"));
        bioskop.setAdresa(rs.getString("adresa"));
        bioskop.setNaziv(rs.getString("nazivbioskopa"));
        bioskop.setSale(new ArrayList<>());
        Film film = new Film();
        film.setNaziv(rs.getString("nazivfilma"));
        film.setReziser(rs.getString("reziser"));
        film.setFilmID(rs.getInt("film"));
        film.postaviZanr(rs.getString("zanr").toUpperCase());
        Sala sala = new Sala();
        sala.setBioskop(bioskop);
        sala.setBrojSale(rs.getInt("sala"));
        int a = rs.getInt("brojredova"), b = rs.getInt("brojmesta");
        int[] dimenzije = {a, b};
        String tehnologija = (rs.getString("tehnologijaprojekcije"));
        TehnologijaProjekcije tehp = null;
        for (TehnologijaProjekcije tp : TehnologijaProjekcije.values()) {
            if (tp.getFormat().equalsIgnoreCase(tehnologija)) {
                tehp = tp;
                break;
            }
        }
        sala.setTehnologijaProjekcije(tehp);
        sala.setDimenzijeSale(dimenzije);
        sala.setBrojSedista(a * b);
        Prikaz prikaz = new Prikaz();
        prikaz.postaviZauzetaMesta(rs.getString("zauzetamesta"));
        prikaz.setPrikazID(rs.getInt("prikaz"));
        prikaz.setBioskop(bioskop);
        prikaz.setFilm(film);
        java.sql.Date sqlDate = rs.getDate("datumprikazivanja");
        Date javaDate = new Date(sqlDate.getTime());
        System.out.println(javaDate);
        prikaz.setDatumPrikazivanja(javaDate);
        java.sql.Timestamp sqlTimestamp = rs.getTimestamp("vremeprikazivanja");
        javaDate = new Date(sqlTimestamp.getTime());
        System.out.println(javaDate);
        prikaz.setVremePrikazivanja(javaDate);
        prikaz.setCena(rs.getInt("cena"));
        prikaz.setSala(sala);
        karta.setPrikaz(prikaz);

        return karta;
    }

    public void izbrisiZauzetoMesto() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
