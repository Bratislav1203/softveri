/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import domen.Bioskop;
import domen.Film;
import domen.Karta;
import domen.User;
import domen.NacinPlacanja;
import domen.Prikaz;
import domen.Rezervacija;
import domen.Sala;
import domen.StavkaRezervacije;
import domen.TehnologijaProjekcije;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Bane
 */
public class TestiranjeKlasa {

    public static List<Bioskop> bioskopi = new ArrayList<>();
    public static List<Sala> sale1 = new ArrayList<>();
    public static List<Sala> sale2 = new ArrayList<>();
    public static List<Sala> sale3 = new ArrayList<>();
    public static List<Sala> sale4 = new ArrayList<>();
    public static List<Sala> sale5 = new ArrayList<>();
    public static List<Prikaz> prikazi = new ArrayList<>();
    public static List<User> korisnici = new ArrayList<>();
    public static List<Karta> karte = new ArrayList<>();
    public static List<Rezervacija> rezervacije = new ArrayList<>();
    public static List<StavkaRezervacije> stavke = new ArrayList<>();
    public static List<Film> filmovi = new ArrayList<>();

    public static void main(String[] args) {

//        // Kreiranje 5 bioskopa
//        Bioskop bioskop1 = new Bioskop(1, "Bioskop 1", "Adresa 1", TehnologijaProjekcije.values(), sale1);
//        Bioskop bioskop2 = new Bioskop(2, "Bioskop 2", "Adresa 2", TehnologijaProjekcije.values(), sale2);
//        Bioskop bioskop3 = new Bioskop(3, "Bioskop 3", "Adresa 3", TehnologijaProjekcije.values(), sale3);
//        Bioskop bioskop4 = new Bioskop(4, "Bioskop 4", "Adresa 4", TehnologijaProjekcije.values(), sale4);
//        Bioskop bioskop5 = new Bioskop(5, "Bioskop 5", "Adresa 5", TehnologijaProjekcije.values(), sale5);
//
//        // Dodavanje bioskopa u listu
//        bioskopi.add(bioskop1);
//        bioskopi.add(bioskop2);
//        bioskopi.add(bioskop3);
//        bioskopi.add(bioskop4);
//        bioskopi.add(bioskop5);
//
//        for (int i = 1; i <= 2; i++) {
//            Sala sala = new Sala(i, bioskop1, TehnologijaProjekcije.TWO_D, new int[]{10, 10}, 100, new int[]{});
//            sale1.add(sala);
//        }
//        for (int i = 1; i <= 2; i++) {
//            Sala sala = new Sala(i, bioskop2, TehnologijaProjekcije.THREE_D, new int[]{10, 10}, 100, new int[]{});
//            sale2.add(sala);
//        }
//        for (int i = 1; i <= 2; i++) {
//            Sala sala = new Sala(i, bioskop3, TehnologijaProjekcije.TWO_D, new int[]{25, 10}, 100, new int[]{});
//            sale3.add(sala);
//        }
//        for (int i = 1; i <= 2; i++) {
//            Sala sala = new Sala(i, bioskop4, TehnologijaProjekcije.TWO_D, new int[]{5, 10}, 100, new int[]{});
//            sale4.add(sala);
//        }
//        for (int i = 1; i <= 2; i++) {
//            Sala sala = new Sala(i, bioskop5, TehnologijaProjekcije.TWO_D, new int[]{10, 12}, 100, new int[]{});
//            sale5.add(sala);
//        }
//        Film film1 = new Film(1, "Film 1", "Režiser 1");
//        Film film2 = new Film(2, "Film 2", "Režiser 2");
//        Film film3 = new Film(3, "Film 3", "Režiser 3");
//
//        filmovi.add(film1);
//        filmovi.add(film2);
//        filmovi.add(film3);
//        Prikaz prikaz1 = new Prikaz(1, new Date(), film1, bioskop1, LocalTime.of(18, 0), bioskop1.getSale().get(0), 250.0);
//        Prikaz prikaz2 = new Prikaz(2, new Date(), film2, bioskop1, LocalTime.of(20, 0), bioskop4.getSale().get(0), 300.0);
//        Prikaz prikaz3 = new Prikaz(3, new Date(), film1, bioskop2, LocalTime.of(19, 30), bioskop5.getSale().get(0), 200.0);
//        Prikaz prikaz4 = new Prikaz(4, new Date(), film3, bioskop2, LocalTime.of(21, 0), bioskop3.getSale().get(0), 180.0);
//        Prikaz prikaz5 = new Prikaz(5, new Date(), film2, bioskop1, LocalTime.of(17, 45), bioskop2.getSale().get(0), 280.0);
//
//        prikazi.add(prikaz1);
//        prikazi.add(prikaz2);
//        prikazi.add(prikaz3);
//        prikazi.add(prikaz4);
//        prikazi.add(prikaz5);
//
//        Karta karta1 = new Karta(1, 1, 1, prikaz1);
//        Karta karta2 = new Karta(2, 2, 3, prikaz2);
//        Karta karta3 = new Karta(3, 1, 2, prikaz3);
//        Karta karta4 = new Karta(4, 3, 5, prikaz4);
//        Karta karta5 = new Karta(5, 2, 4, prikaz5);
//
//        karte.add(karta1);
//        karte.add(karta2);
//        karte.add(karta3);
//        karte.add(karta4);
//        karte.add(karta5);
//
//        Rezervacija rezervacija = new Rezervacija(1, NacinPlacanja.KARTICA, new Korisnik(), stavke);
//
//        StavkaRezervacije stavka1 = new StavkaRezervacije(1, rezervacija, karta1);
//        StavkaRezervacije stavka2 = new StavkaRezervacije(2, rezervacija, karta2);
//        StavkaRezervacije stavka3 = new StavkaRezervacije(3, rezervacija, karta3);
//
//        rezervacija.getStavke().add(stavka1);
//        rezervacija.getStavke().add(stavka2);
//        rezervacija.getStavke().add(stavka3);
//
//        rezervacije.add(rezervacija);

    }
}
