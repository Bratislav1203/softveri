/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package validator;

/**
 *
 * @author Bratislav
 */
public class ValidatorException extends Exception{
    public ValidatorException(String message){
        super(message);
    }
}
