/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import domen.Bioskop;
import domen.Film;
import domen.Karta;
import domen.Prikaz;
import domen.Rezervacija;
import domen.Sala;
import domen.StavkaRezervacije;
import domen.User;
import java.io.IOException;
import java.net.Socket;
import java.time.LocalDate;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import komunikacija.Operation;
import komunikacija.Receiver;
import komunikacija.Request;
import komunikacija.Response;
import komunikacija.Sender;
import validator.ValidatorException;

/**
 *
 * @author Bratislav
 */
public class Communication {

    Socket socket;
    Sender sender;
    Receiver receiver;
    Request request;
    Response response;
    private static Communication instance;
    private User user;

    private Communication() throws IOException {
        socket = new Socket("localhost", 9000);
        sender = new Sender(socket);
        receiver = new Receiver(socket);
    }

    public static Communication getInstance() throws IOException {
        if (instance == null) {
            instance = new Communication();
        }

        return instance;
    }

    public Object logIn(String username, String password) {
        try {
            User user = new User(username, password);
            request = new Request(Operation.LOGIN, user);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                this.user = (User) response.getResult();
                return response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public List<Prikaz> getPrikazi() {
        try {
            request = new Request(Operation.GET, new Prikaz());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<Prikaz>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public User createUser(User user) {
        try {
            request = new Request(Operation.CREATE, user);
            sender.send(request);
            response = (Response) receiver.receive();
            return (User) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }
    public Prikaz createPrikaz(Prikaz prikaz) {
        try {
            request = new Request(Operation.CREATE, prikaz);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Prikaz) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public Object addPrikaz(Prikaz p) {
        try {
            request = new Request(Operation.ADD, p);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Object updateUser(User user) {
        try {
            request = new Request(Operation.UPDATE, user);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public boolean deletePrikaz(Prikaz p) {
        try {
            request = new Request(Operation.DELETE, p);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public boolean deleteBioskop(Bioskop b) {
        try {
            request = new Request(Operation.DELETE, b);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public List<Bioskop> getBioskopi() {
        try {
            request = new Request(Operation.GET, new Bioskop());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<Bioskop>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public Object updatePrikaz(Prikaz p) {
        try {
            request = new Request(Operation.UPDATE, p);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public List<User> getUsers() {
        try {
            request = new Request(Operation.GET, new User());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<User>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public List<Karta> getKarte() {
        try {
            request = new Request(Operation.GET, new Karta());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<Karta>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public List<Film> getFilms() {
        try {
            request = new Request(Operation.GET, new Film());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<Film>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());;
        }

        return null;
    }

    public Bioskop createBioskop(Bioskop bioskop) {
        try {
            request = new Request(Operation.CREATE, bioskop);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Bioskop) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return null;
    }

    public Sala createSala(Sala sala) {
        try {
            request = new Request(Operation.CREATE, sala);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Sala) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }

        return null;
    }

    public Object updateBioskop(Bioskop bioskop) {
        try {
            request = new Request(Operation.UPDATE, bioskop);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }

    }

    public boolean deleteUser(User user) {
        try {
            request = new Request(Operation.DELETE, user);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Object updateFilm(Film film) {
        try {
            request = new Request(Operation.UPDATE, film);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Object addSala(Sala sala) {
        try {
            request = new Request(Operation.ADD, sala);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public List<Rezervacija> getRezervacije() {
        try {
            request = new Request(Operation.GET, new Rezervacija());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<Rezervacija>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public List<StavkaRezervacije> getStavke() {
        try {
            request = new Request(Operation.GET, new StavkaRezervacije());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<StavkaRezervacije>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public boolean deleteSala(Sala sala) {
        try {
            request = new Request(Operation.DELETE, sala);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Film createFilm(Film film) {
        try {
            request = new Request(Operation.CREATE, film);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Film) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public boolean deleteRezervacija(Rezervacija rezervacija) {
        try {
            request = new Request(Operation.DELETE, rezervacija);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public boolean deleteKarta(Karta karta) {
        try {
            request = new Request(Operation.DELETE, karta);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Object updateRezervacija(Rezervacija rezervacija) {
        try {
            request = new Request(Operation.UPDATE, rezervacija);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Object updateSala(Sala sala) {
        try {
            request = new Request(Operation.UPDATE, sala);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public boolean deleteStavkaRezervacije(StavkaRezervacije stavkaRezervacije) {
        try {
            request = new Request(Operation.DELETE, stavkaRezervacije);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Rezervacija createRezervacija(Rezervacija rezervacija) {
        try {
            request = new Request(Operation.CREATE, rezervacija);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Rezervacija) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public Karta createKarta(Karta karta) {
        try {
            request = new Request(Operation.CREATE, karta);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Karta) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public Sala getOneSala(Sala sala) {
        try {
            request = new Request(Operation.GET_ONE, sala);
            sender.send(request);
            response = (Response) receiver.receive();
            return (Sala) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public Object updateStavkaRezervacije(StavkaRezervacije stavkaRezervacije) {
        try {
            request = new Request(Operation.UPDATE, stavkaRezervacije);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public StavkaRezervacije createStavkaRezervacije(StavkaRezervacije stavkaRezervacije) {
        try {
            request = new Request(Operation.CREATE, stavkaRezervacije);
            sender.send(request);
            response = (Response) receiver.receive();
            return (StavkaRezervacije) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public List<Sala> getSale() {
        try {
            request = new Request(Operation.GET, new Sala());
            sender.send(request);
            response = (Response) receiver.receive();
            return (List<Sala>) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
        return null;
    }

    public boolean deleteFilm(Film film) {
        try {
            request = new Request(Operation.DELETE, film);
            sender.send(request);
            response = (Response) receiver.receive();
            return (boolean) response.getResult();
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public Object addStavkaRezervacije(StavkaRezervacije stavkaRezervacije) {
        try {
            request = new Request(Operation.ADD, stavkaRezervacije);
            sender.send(request);
            response = (Response) receiver.receive();
            if (response.getException() == null) {
                return (boolean) response.getResult();
            } else {
                return response.getException().getMessage();
            }
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return false;
        }
    }

    public User getUser() {
        return user;
    }
}
