/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeli;

import domen.Bioskop;
import domen.Prikaz;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Bratislav1203
 */
public class ModelTabelePrikazi extends AbstractTableModel{
     List<Prikaz> prikazi;
     
    
    public ModelTabelePrikazi(List<Prikaz> prikazi){
        this.prikazi = prikazi;
    }
    @Override
    public int getRowCount() {
        return prikazi.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Prikaz prikaz = prikazi.get(rowIndex);
        switch(columnIndex){
            case 0:
                return prikaz.getBioskop().getNaziv();
            case 1:
                return prikaz.getFilm().getNaziv();
            case 2:
                return prikaz.getSala().getBrojSale();
            case 3:
                return sdf.format(prikaz.getDatumPrikazivanja());
            case 4:
                sdf = new SimpleDateFormat("HH:mm");
                return sdf.format(prikaz.getVremePrikazivanja());
            case 5:
                return prikaz.getCena();

        }
        
        return "n/a";
    }
    
    
    
    @Override
    public String getColumnName(int column) {
        String[] columnNames = {"Bioskop","Film", "Sala","Datum prikazivanja","Vreme prikazivanja", "Cena"};
        return columnNames[column];
    }
    
    public List<Prikaz> getPrikazi(){
        return prikazi;
    }
    
    
    
    public void remove(Prikaz prikaz){
        prikazi.remove(prikaz);
        fireTableDataChanged();
    }



   
}
