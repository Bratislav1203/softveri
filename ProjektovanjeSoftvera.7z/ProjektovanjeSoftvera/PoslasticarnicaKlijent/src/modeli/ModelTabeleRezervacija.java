/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.Karta;
import domen.Rezervacija;
import domen.StavkaRezervacije;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Bane
 */
public class ModelTabeleRezervacija extends AbstractTableModel {

    List<Rezervacija> rezervacije;

    public ModelTabeleRezervacija(List<Rezervacija> rezervacije) {
        this.rezervacije = rezervacije;

    }

    @Override
    public int getRowCount() {
        return rezervacije.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Rezervacija rezervacija = rezervacije.get(rowIndex);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm");
        switch (columnIndex) {
            case 0:
                return rezervacija.getStavke().get(0).getKarta().getPrikaz().getFilm().getNaziv();
            case 1:
                return rezervacija.getStavke().get(0).getKarta().getPrikaz().getBioskop().getNaziv();
            case 2:
                return rezervacija.getStavke().get(0).getKarta().getPrikaz().getSala().getBrojSale();
            case 3:
                return sdf.format(rezervacija.getStavke().get(0).getKarta().getPrikaz().getDatumPrikazivanja());
            case 4:
                return sdf1.format(rezervacija.getStavke().get(0).getKarta().getPrikaz().getVremePrikazivanja());
        }

        return "n/a";
    }

    @Override
    public String getColumnName(int column) {
        String[] columnNames = {"FILM", "BIOSKOP", "SALA", "DATUM", "VREME"};
        return columnNames[column];
    }

    public List<Rezervacija> getRezervacije() {
        return rezervacije;
    }

    public void remove(Rezervacija rezervacija) {
        rezervacije.remove(rezervacija);
        fireTableDataChanged();
    }


}
