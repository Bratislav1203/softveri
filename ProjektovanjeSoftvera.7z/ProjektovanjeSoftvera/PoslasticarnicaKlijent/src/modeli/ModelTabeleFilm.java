/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.Prikaz;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Bane
 */
public class ModelTabeleFilm extends AbstractTableModel{
    List<Prikaz> prikazi;
    
    public ModelTabeleFilm(List<Prikaz> prikazi){
        this.prikazi = prikazi;
        
    }
    @Override
    public int getRowCount() {
        return prikazi.size();
    }

    @Override
    public int getColumnCount() {
        return 5;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Prikaz prikaz = prikazi.get(rowIndex);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat sdf1 = new SimpleDateFormat("HH:mm");
        switch(columnIndex){
            case 0:
                return prikaz.getBioskop().getNaziv();
            case 1:
                return prikaz.getSala().getBrojSale();
            case 2:
                return sdf.format(prikaz.getDatumPrikazivanja());
            case 3:
                return sdf1.format(prikaz.getVremePrikazivanja());
            case 4: 
                return prikaz.getCena();
                

        }
        
        return "n/a";
    }

    @Override
    public String getColumnName(int column) {
        String[] columnNames = {"BIOSKOP","SALA","DATUM","VREME", "CENA"};
        return columnNames[column];
    }
    
    public List<Prikaz> getPrikazi(){
        return prikazi;
    }
    
    public void remove(Prikaz prikaz ){
        prikazi.remove(prikaz);
        fireTableDataChanged();
    }
   
}
