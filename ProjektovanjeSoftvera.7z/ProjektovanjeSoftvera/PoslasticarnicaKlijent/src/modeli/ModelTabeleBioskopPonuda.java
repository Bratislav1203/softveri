/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.Bioskop;
import domen.Prikaz;
import java.text.SimpleDateFormat;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Bane
 */
public class ModelTabeleBioskopPonuda extends AbstractTableModel {

    List<Prikaz> prikazi;

    public ModelTabeleBioskopPonuda(List<Prikaz> prikazi) {
        this.prikazi = prikazi;

    }

    @Override
    public int getRowCount() {
        return prikazi.size();
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Prikaz prikaz = prikazi.get(rowIndex);
        SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");
        SimpleDateFormat formatter1 = new SimpleDateFormat("HH:mm");
        switch (columnIndex) {
            case 0:
                return prikaz.getFilm().getNaziv();
            case 1:
                return prikaz.getSala().getBrojSale();
            case 2:
                return formatter.format(prikaz.getDatumPrikazivanja());
            case 3:
                return formatter1.format(prikaz.getVremePrikazivanja());
            case 4:
                return prikaz.getSala().getTehnologijaProjekcije().getFormat();
            case 5:
                return prikaz.getCena();
        }

        return "n/a";
    }

    @Override
    public String getColumnName(int column) {
        String[] columnNames = {"FILM", "SALA", "DATUM", "VREME", "TEHNOLOGIJA PROJEKCIJE", "CENA", "SLOBODNA MESTA"};
        return columnNames[column];
    }

    public List<Prikaz> getPrikazi() {
        return prikazi;
    }

    public void remove(Prikaz prikaz) {
        prikazi.remove(prikaz);
        fireTableDataChanged();
    }

}
