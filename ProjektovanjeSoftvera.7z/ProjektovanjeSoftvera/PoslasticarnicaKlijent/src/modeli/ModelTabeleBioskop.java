/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modeli;

import domen.Bioskop;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Bratislav1203
 */
public class ModelTabeleBioskop extends AbstractTableModel{
     List<Bioskop> bioskopi;
     
    
    public ModelTabeleBioskop(List<Bioskop> bioskopi){
        this.bioskopi = bioskopi;
    }
    @Override
    public int getRowCount() {
        return bioskopi.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        
        Bioskop bioskop = bioskopi.get(rowIndex);
        switch(columnIndex){
            case 0:
                return bioskop.getNaziv();
            case 1:
                return bioskop.getAdresa();
            case 2:
                return bioskop.ispisiTehnologije();

        }
        
        return "n/a";
    }
    
    
    
    @Override
    public String getColumnName(int column) {
        String[] columnNames = {"Naziv","Adresa", "Tehnologija projekcije"};
        return columnNames[column];
    }
    
    public List<Bioskop> getBioskopi(){
        return bioskopi;
    }
    
    
    
    public void remove(Bioskop bioskop){
        bioskopi.remove(bioskop);
        fireTableDataChanged();
    }



   
}
