/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeli;

import domen.Sala;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Bratislav
 */
public class ModelTabeleSala extends AbstractTableModel{
    List<Sala> sale;
     
    
    public ModelTabeleSala(List<Sala> sale){
        this.sale = sale;
    }
    @Override
    public int getRowCount() {
        return sale.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }

    
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Sala sala = sale.get(rowIndex);
        switch(columnIndex){
            case 0:
                return sala.getBrojSale();
            case 1:
                return sala.getBrojSedista();
            case 2:
                return sala.getTehnologijaProjekcije().getFormat();

        }
        
        return "n/a";
    }
    
    
    
    @Override
    public String getColumnName(int column) {
        String[] columnNames = {"Broj sale", "Broj mesta", "Tehnologija projekcije"};
        return columnNames[column];
    }
    
    public List<Sala> getSale(){
        return sale;
    }
    
    
    
    public void remove(Sala sala){
        sale.remove(sala);
        fireTableDataChanged();
    }



}
